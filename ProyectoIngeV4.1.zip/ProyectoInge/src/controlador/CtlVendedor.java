/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.VendedorDAO;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelo.Vendedor;

/**
 *
 * @author USUARIO WINDOWS
 */
public class CtlVendedor {
    
    VendedorDAO dao = new VendedorDAO();
    LogicaVendedor lb = new LogicaVendedor();
    
    public boolean guardar(int codigo,int cedula, String nombre, String apellido, String correo, int celular, String direccion){
        return lb.crearVendedor(codigo, cedula, nombre, apellido, correo, celular, direccion);
    }
    public boolean modificar(int codigo,int cedula, String nombre, String apellido, String correo, int celular, String direccion){
        return lb.modificar(codigo, cedula, nombre, apellido, correo, celular, direccion);
    }
    public boolean eliminar(int codigo){
        return lb.eliminar(codigo);
    }
    public Vendedor buscar(int codigo){
        return lb.buscar(codigo);
    }
    
    public ArrayList<Vendedor> listar(){
        return lb.listar();
    }
    
}
