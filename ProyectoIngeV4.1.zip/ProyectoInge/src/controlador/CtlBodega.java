/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import BO.BOlistadoProductos;
import DAO.BodegaDAO;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelo.Bodega;

/**
 *
 * @author USUARIO WINDOWS
 */
public class CtlBodega {
    
    BodegaDAO dao = new BodegaDAO();
    //lb significa logicaBodega
    LogicaBodega lb = new LogicaBodega();
    
    public boolean guardar(int codigo, String nombre, String direccion, int telefono){
        return lb.crearBodega(codigo, nombre, direccion, telefono);
    }
    public boolean modificar(int codigo, String nombre, String direccion, int telefono){
        return lb.modificar(codigo, nombre, direccion, telefono);
    }
    public boolean eliminar(int codigo){
        return lb.eliminar(codigo);
    }
    public Bodega buscar(int codigo){
        return lb.buscar(codigo);
    }
    
    public ArrayList<Bodega> listar() {
        return lb.listar();
    }
    
}
