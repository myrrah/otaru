/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import BO.BOlistadoProductos;
import DAO.DAOProductos;
import DAO.DAOProveedores;
import DAO.DAOcatProductos;
import java.util.ArrayList;
import modelo.CategoriaProducto;
import modelo.Producto;
import modelo.Proveedores;

/**
 *
 * @author Drago1
 */
public class Logica {

    DAOcatProductos daoCat = new DAOcatProductos();
    DAOProveedores daoPro = new DAOProveedores();
    DAOProductos daoProductos = new DAOProductos();

    // logica para la gestion de las categorias de los productos
    public boolean crearCategoriaProducto(int codigo, String nombre, String descripcion) {
        CategoriaProducto ca = new CategoriaProducto();
        ca = daoCat.buscarCategoriaProductosCodigo(codigo);
        if (ca == null) {
            return false;
        }
        if (ca != null) {
            if (codigo == ca.getCodigo()) {
                return false;
            } else {
                System.out.println("llegue");
                CategoriaProducto cap = new CategoriaProducto(codigo, nombre, descripcion);
                daoCat.guardarCategoriaProductos(cap);
                return true;
            }
        } else {
            return false;
        }
    }

    public CategoriaProducto buscarCategoria(String nombre) {
        return daoCat.buscarCategoriaProductos(nombre);
    }

    public boolean modificarCategoria(int codigo, String nombre, String descripcion) {
        CategoriaProducto ca = new CategoriaProducto();
        ca = daoCat.buscarCategoriaProductosCodigo(codigo);
        System.out.println(ca.getCodigo());
        if (codigo == ca.getCodigo()) {
            CategoriaProducto cat = new CategoriaProducto(codigo, nombre, descripcion);
            daoCat.modificarCategoria(cat);
            return true;
        }
        return false;
    }

    public boolean eliminarCategoria(int codigo) {
        if (daoCat.eliminarCategoriaProductos(codigo)) {
            return true;
        } else {
            return false;
        }
    }

    public CategoriaProducto buscarCategoriaCodigo(int codigo) {
        return daoCat.buscarCategoriaProductosCodigo(codigo);
    }

    public ArrayList<CategoriaProducto> listar() {
        return daoCat.listarCategoriaProductos();
    }

    //logica para gestionar proveedores
    public boolean crearProveedor(int codigo, String nombre, String correo, int telefono, String direccion) {
        Proveedores pro = new Proveedores(codigo, nombre, correo, telefono, direccion);
        Proveedores proVal = new Proveedores();
        proVal = daoPro.buscarProveedor(codigo);
        if (proVal.getCodigo() == codigo) {
            return false;
        } else {
            daoPro.guardarProveedor(pro);
            return true;
        }
    }

    public Proveedores buscarProveedores(int codigo) {
        return daoPro.buscarProveedor(codigo);
    }

    public boolean eliminarProveedor(int codigo) {
        return daoPro.eliminarProveedor(codigo);
    }

    public boolean modificarProveedor(int codigo, String nombre, String correo, int telefono, String direccion) {
        Proveedores pro = new Proveedores();
        //se busca mediante el codigo para validar la existencia del proveedor
        pro = daoPro.buscarProveedor(codigo);
        if (pro.getCodigo() == codigo) {
            //se crea el objeto el cual sera el que modificara la base de datos
            Proveedores pro2 = new Proveedores(codigo, nombre, correo, telefono, direccion);
            if (daoPro.modificarProveedor(pro)) {
                return true;
            }
        }
        return false;

    }
    
    public ArrayList<Proveedores> listarProveedores() {
        return daoPro.listarProveedor();
    }
    
    // metodos para la gestion de productos
    
    public boolean crearProducto(int codigo, String nombre, String umedida, int idcategoria, int idproveedor, double precio) {
        Producto pro = new Producto(codigo, nombre, umedida, idcategoria, idproveedor, precio);
        if (daoProductos.buscarProducto(codigo).getCodigo() == codigo) {
            return false;
        } else {
            daoProductos.guardarProducto(pro);
            return true;
        }
    }

    public Producto buscarProductos(int codigo) {
        return daoProductos.buscarProducto(codigo);
    }

    public boolean eliminarProducto(int codigo) {
        return daoProductos.eliminarProducto(codigo);
    }

    public boolean modificarProductos(int codigo, String nombre, String umedida, int idcategoria, int idproveedor, double precio) {
        //se busca mediante el codigo para validar la existencia del proveedor
        if (daoProductos.buscarProducto(codigo).getCodigo() == codigo) {
            //se crea el objeto el cual sera el que modificara la base de datos
            Producto pro = new Producto(codigo, nombre, umedida, idcategoria, idproveedor, precio);
            if (daoProductos.modificarProducto(pro)) {
                return true;
            }
        }
        return false;

    }
    

    
    //logica para listado de prodcutos usando un BO
    public ArrayList<BOlistadoProductos> listarProducto(){
        ArrayList<Producto> listaPro = new ArrayList<>();
        listaPro=daoProductos.listarProducto();
        ArrayList<BOlistadoProductos> listaProductos= new ArrayList<>();
        for (int i = 0; i < listaPro.size(); i++) {
            Producto pro = new Producto();
            pro=listaPro.get(i);
            String categoria=daoCat.buscarCategoriaProductosCodigo(pro.getIdCategoria()).getNombre();
            String proveedor=daoPro.buscarProveedor(pro.getIdProveedor()).getNombre();
            BOlistadoProductos BOlistado = new BOlistadoProductos(pro.getCodigo(),pro.getNombre(),pro.getUmedida(),
            categoria,proveedor,pro.getPrecio());
            listaProductos.add(BOlistado);
        }
        return listaProductos;
    }
        public ArrayList<Producto> listarpro() {
        return daoProductos.listarProducto();
    }
    
}
