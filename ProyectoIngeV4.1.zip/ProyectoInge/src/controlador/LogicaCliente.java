/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.ClienteDAO;
import java.util.ArrayList;
import modelo.Bodega;
import modelo.Cliente;

/**
 *
 * @author Drago1
 */
public class LogicaCliente {
    ClienteDAO cliDao = new ClienteDAO();
    
    public boolean crearCliente(int cedula, String nombre, String apellido, String correo, int celular, String direccion) {
        Cliente cliente = new Cliente(cedula, nombre,apellido,correo,celular, direccion);
        if (cliDao.buscarCliente(cedula).getCedula()== cedula) {
            return false;
        } else {
            if (cliDao.guardarCliente(cliente)) {
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean modificar(int cedula, String nombre, String apellido, String correo, int celular, String direccion) {
        Cliente cliente = new Cliente(cedula, nombre,apellido,correo,celular, direccion);
        if (cliDao.buscarCliente(cedula).getCedula()== cedula) {
            if (cliDao.modificarCliente(cliente)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean eliminar(int codigo) {
        if (cliDao.eliminarClinete(codigo)) {
            return true;
        } else {
            return false;
        }
    }

    public Cliente buscar(int cedula) {
        if (cliDao.buscarCliente(cedula).getCedula()== cedula) {
            return cliDao.buscarCliente(cedula);
        } else {
            return null;
        }
    }
    
    public ArrayList<Cliente> listar(){
        return cliDao.listar();
    }

}
