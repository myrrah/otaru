/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Cliente;
import modelo.Vendedor;
/**
 *
 * @author Drago1
 */
public class VendedorDAO extends Conexion{
    public boolean guardarVendedor(Vendedor vendedor) {
        String consulta = "insert into vendedor (codigo,cedula,nombre,apellido,correo,telefono,direccion) "
                + "values"
                + "('"+ vendedor.getCodigo()+ "','" + vendedor.getCedula()+ "','"+ vendedor.getNombre()+ "','"
                + vendedor.getApellido()+ "','"
                + vendedor.getCorreo()+ "','"
                + vendedor.getCelular()+ "','" + vendedor.getDireccion()+ "');";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }
    
    public Vendedor buscarVendedor(int codigo) {
        String consulta = "select codigo,cedula,nombre,apellido,correo,telefono,direccion from vendedor "
                + "where codigo='" + codigo + "'";
        Vendedor vendedor = new Vendedor();
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                vendedor.setCodigo(resultadoDB.getInt("codigo"));
                vendedor.setCedula(resultadoDB.getInt("cedula"));
                vendedor.setNombre(resultadoDB.getString("nombre"));
                vendedor.setApellido(resultadoDB.getString("apellido"));
                vendedor.setCorreo(resultadoDB.getString("correo"));
                vendedor.setCelular(resultadoDB.getInt("telefono"));
                vendedor.setDireccion(resultadoDB.getString("direccion"));
            }
        } catch (SQLException ex) {
            System.out.println("Esto se Tosto");
        }
        return vendedor;
    }
    
    public boolean modificarVendedor(Vendedor vendedor) {
        String consulta = "update vendedor set cedula='" + vendedor.getCedula()
                + "',nombre='" + vendedor.getNombre()
                + "',apellido='" + vendedor.getApellido()
                + "',correo='" + vendedor.getCorreo()
                + "',telefono='" + vendedor.getCelular()
                + "',direccion='" + vendedor.getDireccion()
                + "' where codigo=" + vendedor.getCodigo();
        return super.ejecutar(consulta);
    }
    
    public boolean eliminarVendedor(int codigo) {
        String consulta = "delete from vendedor where codigo=" + codigo;
        return super.ejecutar(consulta);
    }
    
     public ArrayList<Vendedor> listar() {
        ArrayList<Vendedor> lista = new ArrayList<>();
        String consulta = "select codigo,cedula,nombre,apellido,correo,telefono,direccion from vendedor ";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                Vendedor vendedor = new Vendedor();
                vendedor.setCodigo(resultadoDB.getInt("codigo"));
                vendedor.setCedula(resultadoDB.getInt("cedula"));
                vendedor.setNombre(resultadoDB.getString("nombre"));
                vendedor.setApellido(resultadoDB.getString("apellido"));
                vendedor.setCorreo(resultadoDB.getString("correo"));
                vendedor.setCelular(resultadoDB.getInt("telefono"));
                vendedor.setDireccion(resultadoDB.getString("direccion"));
                lista.add(vendedor);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }
    
}
