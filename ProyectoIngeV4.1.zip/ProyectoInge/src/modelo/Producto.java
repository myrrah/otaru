/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Drago1
 */
public class Producto {
    int codigo;
    String nombre;
    //umedida hace referencia a unidades de medida, ejemplo, 5 kg
    String umedida;
    int idCategoria;
    int idProveedor;
    double precio;
    public Producto() {
    }

    public Producto(int codigo, String nombre, String umedida, int idCategoria, int idProveedor, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.umedida = umedida;
        this.idCategoria = idCategoria;
        this.idProveedor = idProveedor;
        this.precio = precio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

  

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }



    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUmedida() {
        return umedida;
    }

    public void setUmedida(String umedida) {
        this.umedida = umedida;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo " + codigo + ", nombre " + nombre + '}';
    }
    
    
    
    
}
