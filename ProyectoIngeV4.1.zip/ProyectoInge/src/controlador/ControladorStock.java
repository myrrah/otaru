/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import BO.BOStock;
import java.util.ArrayList;
import modelo.Bodega;
import modelo.Producto;

/**
 *
 * @author Drago1
 */
public class ControladorStock {
    LogicaStock ls = new LogicaStock();
    public boolean guardar(Bodega bodega, Producto pro, int cantidad){
        return ls.guardar(bodega,pro,cantidad);
    }
    public boolean modificar(Bodega bodega, Producto pro, int cantidad){
        return ls.modificar(bodega,pro,cantidad);
    }
    public ArrayList<BOStock> listar(Bodega bodega){
        return ls.listar(bodega);
    }
    
}
