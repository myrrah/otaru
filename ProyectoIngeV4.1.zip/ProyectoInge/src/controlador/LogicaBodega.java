/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.BodegaDAO;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Bodega;
import modelo.CategoriaProducto;

/**
 *
 * @author Drago1
 */
public class LogicaBodega {

    BodegaDAO daoB = new BodegaDAO();

    public boolean crearBodega(int codigo, String nombre, String direccion, int telefono) {
        Bodega bodega = new Bodega(codigo, nombre, direccion, telefono);
        if (daoB.buscarBodega(codigo).getCodigo() == codigo) {
            return false;
        } else {
            if (daoB.guardarBodega(bodega)) {
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean modificar(int codigo, String nombre, String direccion, int telefono) {
        Bodega bodega = new Bodega(codigo, nombre, direccion, telefono);
        if (daoB.buscarBodega(codigo).getCodigo() == codigo) {
            if (daoB.modificarBodega(bodega)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean eliminar(int codigo) {
        if (daoB.eliminarBodega(codigo)) {
            return true;
        } else {
            return false;
        }
    }

    public Bodega buscar(int codigo) {
        if (daoB.buscarBodega(codigo).getCodigo() == codigo) {
            return daoB.buscarBodega(codigo);
        } else {
            return null;
        }
    }

    public ArrayList<Bodega> listar() {
        return daoB.listarBodega();
    }

}
