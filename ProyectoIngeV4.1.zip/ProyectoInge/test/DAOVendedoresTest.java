/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DAO.ClienteDAO;
import DAO.VendedorDAO;
import modelo.Cliente;
import modelo.Proveedores;
import modelo.Vendedor;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Drago1
 */
public class DAOVendedoresTest {

    private Vendedor vendedor;
    private VendedorDAO vendedorDAO;

    @Test
    public void registrar() {
        System.out.println("Entro a test crear producto");

        vendedor = new Vendedor(1313,1222, "bra bra", "ss", "el corre", 73, "aremenia");

        vendedorDAO = new VendedorDAO();

        boolean resultadoObtenido = vendedorDAO.guardarVendedor(vendedor);
        boolean resultadoEsperado = true;

        Vendedor vendedorBuscado = vendedorDAO.buscarVendedor(vendedor.getCodigo());
        if (vendedorBuscado.getCodigo() == vendedor.getCodigo()) {
            resultadoObtenido = true;
        } else {
            resultadoObtenido = false;
        }

        assertEquals(resultadoObtenido, resultadoEsperado);

    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
