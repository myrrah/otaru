/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.VendedorDAO;
import java.util.ArrayList;
import modelo.Cliente;
import modelo.Vendedor;

/**
 *
 * @author Drago1
 */
public class LogicaVendedor {

    VendedorDAO vDao = new VendedorDAO();

    public boolean crearVendedor(int codigo, int cedula, String nombre, String apellido, String correo, int celular, String direccion) {
        Vendedor vendedor = new Vendedor(codigo, cedula, nombre, apellido, correo, celular, direccion);
        if (vDao.buscarVendedor(cedula).getCedula() == cedula) {
            return false;
        } else {
            if (vDao.guardarVendedor(vendedor)) {
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean modificar(int codigo, int cedula, String nombre, String apellido, String correo, int celular, String direccion) {
        Vendedor vendedor = new Vendedor(codigo, cedula, nombre, apellido, correo, celular, direccion);
        if (vDao.buscarVendedor(codigo).getCodigo()== codigo) {
            if (vDao.modificarVendedor(vendedor)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean eliminar(int codigo) {
        if (vDao.eliminarVendedor(codigo)) {
            return true;
        } else {
            return false;
        }
    }

    public Vendedor buscar(int codigo) {
        if (vDao.buscarVendedor(codigo).getCodigo() == codigo) {
            return vDao.buscarVendedor(codigo);
        } else {
            return null;
        }
    }

    public ArrayList<Vendedor> listar() {
        return vDao.listar();
    }
}
