/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.CategoriaProducto;
import modelo.Proveedores;

/**
 *
 * @author Drago1
 */
public class DAOProveedores extends Conexion {

    public boolean guardarProveedor(Proveedores pro) {
        String consulta = "INSERT INTO proveedor (codigo,nombre,"
                + "correo,telefono,direccion) "
                + "VALUES ('" + pro.getCodigo() + " ', '" + pro.getNombre() + " ', '" + pro.getCorreo()
                + " ', '" + pro.getTelefono()
                + "','" + pro.getDireccion() + "'); ";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

    public Proveedores buscarProveedor(int codigo) {
        String consulta = "select codigo,nombre,"
                + "correo,telefono,direccion from proveedor where codigo ='" + codigo + "'";
        Proveedores pro = new Proveedores();
        System.out.println(consulta);
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                pro.setCodigo(resultadoDB.getInt("codigo"));
                pro.setNombre(resultadoDB.getString("nombre"));
                pro.setCorreo(resultadoDB.getString("correo"));
                pro.setTelefono(resultadoDB.getInt("telefono"));
                pro.setDireccion(resultadoDB.getString("direccion"));
            }
        } catch (SQLException ex) {
            System.out.println("Fallo al consultar");
            return null;
        }
        return pro;

    }

    public CategoriaProducto buscarProveedor2(int codigo) {
        String consulta = "select codigo,nombre,"
                + "descripcion from categoriaproductos where codigo ='" + codigo + "'";
        CategoriaProducto cap = new CategoriaProducto();
        System.out.println(consulta);
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                cap.setCodigo(resultadoDB.getInt("codigo"));
                cap.setNombre(resultadoDB.getString("nombre"));
                cap.setDescripcion(resultadoDB.getString("descripcion"));
            }
        } catch (SQLException ex) {
            System.out.println("Fallo al consultar");
            return null;
        }
        return cap;

    }

    public ArrayList<Proveedores> listarProveedor() {
        ArrayList<Proveedores> lista = new ArrayList<>();
        String consulta = "select codigo,nombre,"
                + "correo,telefono,direccion from proveedor";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                Proveedores pro = new Proveedores();
                pro.setCodigo(resultadoDB.getInt("codigo"));
                pro.setNombre(resultadoDB.getString("nombre"));
                pro.setCorreo(resultadoDB.getString("correo"));
                pro.setTelefono(resultadoDB.getInt("telefono"));
                pro.setDireccion(resultadoDB.getString("direccion"));
                lista.add(pro);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }

    public boolean eliminarProveedor(int codigo) {
        String consulta = "delete from proveedor where codigo =" + codigo;
        return super.ejecutar(consulta);
    }

    public boolean modificarProveedor(Proveedores pro) {
        String consulta = "UPDATE proveedor SET codigo='" + pro.getCodigo() + "', "
                + " nombre='" + pro.getNombre() + "', correo='" + pro.getCorreo()+ "', "
                +" telefono='" + pro.getTelefono()+ "', direccion='"+ pro.getDireccion()+"'"
                + " WHERE codigo='" + pro.getCodigo() + "'";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

}
