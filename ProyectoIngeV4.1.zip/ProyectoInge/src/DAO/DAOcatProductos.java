/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.CategoriaProducto;

/**
 *
 * @author Drago1
 */
public class DAOcatProductos extends Conexion {

    public boolean guardarCategoriaProductos(CategoriaProducto cap) {
        String consulta = "INSERT INTO categoriaproductos (codigo,nombre,"
                + "descripcion) "
                + "VALUES ('" + cap.getCodigo() + " ', '" + cap.getNombre() + "','" + cap.getDescripcion() + "'); ";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

    public CategoriaProducto buscarCategoriaProductos(String nombre) {
        String consulta = "select codigo,nombre,"
                + "descripcion from categoriaproductos where nombre ='" + nombre + "'";
        CategoriaProducto cap = new CategoriaProducto();
        System.out.println(consulta);
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                cap.setCodigo(resultadoDB.getInt("codigo"));
                cap.setNombre(resultadoDB.getString("nombre"));
                cap.setDescripcion(resultadoDB.getString("descripcion"));
            }
        } catch (SQLException ex) {
            System.out.println("Fallo al consultar");
            return null;
        }
        return cap;

    }

    public CategoriaProducto buscarCategoriaProductosCodigo(int codigo) {
        String consulta = "select codigo,nombre,"
                + "descripcion from categoriaproductos where codigo ='" + codigo + "'";
        CategoriaProducto cap = new CategoriaProducto();
        System.out.println(consulta);
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                cap.setCodigo(resultadoDB.getInt("codigo"));
                cap.setNombre(resultadoDB.getString("nombre"));
                cap.setDescripcion(resultadoDB.getString("descripcion"));
            }
        } catch (SQLException ex) {
            System.out.println("Fallo al consultar");
            return null;
        }
        return cap;

    }

    public ArrayList<CategoriaProducto> listarCategoriaProductos() {
        ArrayList<CategoriaProducto> lista = new ArrayList<>();
        String consulta = "select codigo,nombre,"
                + " descripcion from CategoriaProductos";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                CategoriaProducto cap = new CategoriaProducto();
                cap.setCodigo(resultadoDB.getInt("codigo"));
                cap.setNombre(resultadoDB.getString("nombre"));
                cap.setDescripcion(resultadoDB.getString("descripcion"));
                lista.add(cap);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }

    public boolean eliminarCategoriaProductos(int codigo) {
        String consulta = "delete from categoriaproductos where codigo =" + codigo;
        return super.ejecutar(consulta);
    }

    public boolean modificarCategoria(CategoriaProducto ca) {
        String consulta = "UPDATE categoriaproductos SET codigo='" + ca.getCodigo()+ "', "
                + " nombre='" + ca.getNombre() + "', descripcion='" + ca.getDescripcion()+ "' "
                + " WHERE codigo='" + ca.getCodigo() + "'";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }
}
