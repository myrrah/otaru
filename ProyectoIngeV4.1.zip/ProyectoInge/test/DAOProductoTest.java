/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DAO.DAOProductos;
import conexion.Conexion;
import modelo.Producto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Drago1
 */
public class DAOProductoTest {

    
    
    private Producto producto;
    private DAOProductos productDao;
    @Test
    public void registrar() {
        System.out.println("Entro a test crear producto");

        producto = new Producto(14, "producto1", "10kg",73,312,2000);

        productDao = new DAOProductos();
        
        boolean resultadoObtenido = productDao.guardarProducto(producto);
        boolean resultadoEsperado=true;
        
        Producto productoBuscado = productDao.buscarProducto(producto.getCodigo());
        if(productoBuscado.getCodigo()==producto.getCodigo()){
            resultadoObtenido=true;
        }else{
            resultadoObtenido=false;
        }

        assertEquals(resultadoObtenido, resultadoEsperado);

    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
