/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import BO.BOlistadoProductos;
import DAO.DAOcatProductos;
import Vista.CategoriaProductos;
import java.util.ArrayList;
import modelo.CategoriaProducto;
import modelo.Producto;
import modelo.Proveedores;

/**
 *
 * @author Drago1
 */
public class Controlador {

    Logica logica = new Logica();

    //controlador para categoria de productos
    public boolean crearCatProductos(int codigo, String nombre, String descripcion) {
        return logica.crearCategoriaProducto(codigo, nombre, descripcion);
    }

    public CategoriaProducto buscarCategoria(String nombre) {
        return logica.buscarCategoria(nombre);
    }

    public CategoriaProducto buscarCategoriaCodigo(int codigo) {
        return logica.buscarCategoriaCodigo(codigo);
    }

    public boolean modificarCategoria(int codigo, String nombre, String descripcion) {
        return logica.modificarCategoria(codigo, nombre, descripcion);
    }

    public boolean eliminarCategoria(int codigo) {
        return logica.eliminarCategoria(codigo);
    }

    public ArrayList<CategoriaProducto> listar() {
        return logica.listar();
    }

    //controlador para proveedores
    public boolean crearProveedor(int codigo, String nombre, String correo, int telefono, String direccion) {
        return logica.crearProveedor(codigo, nombre, correo, telefono, direccion);
    }

    public boolean modificarProveedor(int codigo, String nombre, String correo, int telefono, String direccion) {
        return logica.modificarProveedor(codigo, nombre, correo, telefono, direccion);
    }

    public boolean eliminarProveedor(int codigo) {
        return logica.eliminarProveedor(codigo);
    }

    public Proveedores buscarProveedores(int codigo) {
        return logica.buscarProveedores(codigo);
    }

    public ArrayList<Proveedores> listarProveedores() {
        return logica.listarProveedores();
    }
    
    // controlador para Productos
    public ArrayList<BOlistadoProductos> listarProductos (){
        return logica.listarProducto();
    }
        public ArrayList<Producto> listarProductos2 (){
        return logica.listarpro();
    }
    
    
    public boolean crearProducto(int codigo, String nombre, String umedida, int idcategoria, int idproveedor, double precio){
        return logica.crearProducto(codigo, nombre, umedida, idcategoria, idproveedor, precio);
    }
    
    public boolean modificarProducto(int codigo, String nombre, String umedida, int idcategoria, int idproveedor, double precio){
        return logica.modificarProductos(codigo, nombre, umedida, idcategoria, idproveedor,precio);
    }
    
    public boolean eliminarProducto(int codigo){
        return logica.eliminarProducto(codigo);
    }
    
    public Producto buscarProducto(int codigo){
        return logica.buscarProductos(codigo);
    }
}
