/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Producto;
import modelo.Stock;

/**
 *
 * @author Drago1
 */
public class DAOStock extends Conexion{
    public boolean guardarStock(Stock stock) {
        String consulta = "INSERT INTO stock (idbodega,idproducto,"
                + "cantidad) "
                + "VALUES ('" + stock.getBodega()+ " ', '" + stock.getProducto()
                + "','" + stock.getCantidad()+ "'); ";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

    public Stock buscarStock(int idbodega) {
        String consulta = "select idbodega,idproducto,"
                + "cantidad from stock where idbodega ='" + idbodega + "'";
        Stock stock = new Stock();
        System.out.println(consulta);
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                stock.setBodega(resultadoDB.getInt("idbodega"));
                stock.setProducto(resultadoDB.getInt("idproducto"));
                stock.setCantidad(resultadoDB.getInt("cantidad"));
            }
        } catch (SQLException ex) {
            System.out.println("Fallo al consultar");
            return null;
        }
        return stock;

    }

   

    public ArrayList<Stock> listar(int idbodega) {
        ArrayList<Stock> lista = new ArrayList<>();
        String consulta = "select idbodega,idproducto,"
                + "cantidad from stock where idbodega ='"+idbodega+"'";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                Stock stock = new Stock();
                stock.setBodega(resultadoDB.getInt("idbodega"));
                stock.setProducto(resultadoDB.getInt("idproducto"));
                stock.setCantidad(resultadoDB.getInt("cantidad"));
                lista.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }

    public boolean modificarStock(Stock stock) {
        String consulta = "UPDATE stock SET idbodega='" + stock.getBodega()+ "', "
                + "', cantidad='" + stock.getBodega()+ "', "
                + " WHERE idproducto='" + stock.getProducto()+ "'";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

    
}
