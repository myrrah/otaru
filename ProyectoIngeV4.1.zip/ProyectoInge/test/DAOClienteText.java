/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DAO.BodegaDAO;
import DAO.ClienteDAO;
import modelo.Bodega;
import modelo.Cliente;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Drago1
 */
public class DAOClienteText {

    private Cliente cliente;
    private ClienteDAO clienteDao;

    @Test
    public void registrar() {
        System.out.println("Entro a test crear producto");

        cliente = new Cliente(12, "bra bra", "ss","el corre", 73,"aremenia");

        clienteDao = new ClienteDAO();

        boolean resultadoObtenido = clienteDao.guardarCliente(cliente);
        boolean resultadoEsperado = true;

        Cliente clienteBuscado = clienteDao.buscarCliente(cliente.getCedula());
        if (clienteBuscado.getCedula() == cliente.getCedula()) {
            resultadoObtenido = true;
        } else {
            resultadoObtenido = false;
        }

        assertEquals(resultadoObtenido, resultadoEsperado);

    }
    public void eliminar(){
    System.out.println("Enrtro a test para eliminar");
    
    cliente = new Cliente (12,"bra bra", "ss", "el corre", 73, "armenia");
    
    clienteDao =new ClienteDAO();
    
    boolean resultadoObtenido = clienteDao.eliminarClinete(cliente.getCedula());
    boolean resultadoEsperado = false;
    
    Cliente clienteBuscado = clienteDao.buscarCliente(cliente.getCedula());
    
    if (clienteBuscado.getCedula() == cliente.getCedula()){
        resultadoObtenido = true;
    } else {
        resultadoObtenido = false;
    }
    
    assertEquals(resultadoObtenido, resultadoEsperado);
}
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
