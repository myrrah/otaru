/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

import Vista.Productos;
import modelo.Bodega;
import modelo.Producto;

/**
 *
 * @author Drago1
 */
public class BOStock {
    Bodega bodega;
    Producto pro;
    int cantidad;

    public BOStock() {
    }

    public BOStock(Bodega bodega, Producto pro, int cantidad) {
        this.bodega = bodega;
        this.pro = pro;
        this.cantidad = cantidad;
    }

    public Bodega getBodega() {
        return bodega;
    }

    public void setBodega(Bodega bodega) {
        this.bodega = bodega;
    }

    public Producto getPro() {
        return pro;
    }

    public void setPro(Producto pro) {
        this.pro = pro;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    
    
}
