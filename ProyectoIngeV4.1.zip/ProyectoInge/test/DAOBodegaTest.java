/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DAO.BodegaDAO;
import DAO.DAOProductos;
import modelo.Bodega;
import modelo.Producto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Drago1
 */
public class DAOBodegaTest {
    
    private Bodega bodega;
    private BodegaDAO bodegaDao;
    @Test
    public void registrar() {
        System.out.println("Entro a test crear producto");

        bodega = new Bodega(12, "bodega del poder", "armenia",73);

        bodegaDao = new BodegaDAO();
        
        boolean resultadoObtenido = bodegaDao.guardarBodega(bodega);
        boolean resultadoEsperado=true;
        
        Bodega bodegaBuscado = bodegaDao.buscarBodega(bodega.getCodigo());
        if(bodegaBuscado.getCodigo()==bodega.getCodigo()){
            resultadoObtenido=true;
        }else{
            resultadoObtenido=false;
        }

        assertEquals(resultadoObtenido, resultadoEsperado);

    }
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
