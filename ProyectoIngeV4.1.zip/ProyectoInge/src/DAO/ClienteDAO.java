/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Bodega;
import modelo.Cliente;

/**
 *
 * @author Drago1
 */
public class ClienteDAO extends Conexion{
    public boolean guardarCliente(Cliente cliente) {
        String consulta = "insert into cliente (cedula,nombre,apellido,correo,telefono,direccion) "
                + "values"
                + "("+ cliente.getCedula()+ ",'" + cliente.getNombre() + "','"+ cliente.getApellido()+ "','"
                + cliente.getCorreo()+ "','"
                + cliente.getCelular()+ "','" + cliente.getDireccion()+ "');";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }
    
    public Cliente buscarCliente(int codigo) {
        String consulta = "select cedula,nombre,apellido,correo,telefono,direccion from cliente "
                + "where cedula='" + codigo + "'";
        Cliente cli = new Cliente();
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                cli.setCedula(resultadoDB.getInt("cedula"));
                cli.setNombre(resultadoDB.getString("nombre"));
                cli.setApellido(resultadoDB.getString("apellido"));
                cli.setCorreo(resultadoDB.getString("correo"));
                cli.setCelular(resultadoDB.getInt("telefono"));
                cli.setDireccion(resultadoDB.getString("direccion"));
            }
        } catch (SQLException ex) {
            System.out.println("Esto se Tosto");
        }
        return cli;
    }
    
    public boolean modificarCliente(Cliente cliente) {
        String consulta = "update cliente set nombre='" + cliente.getNombre()
                + "',apellido='" + cliente.getApellido()
                + "',correo='" + cliente.getCorreo()
                + "',telefono='" + cliente.getCelular()
                + "',direccion='" + cliente.getDireccion()
                + "' where cedula=" + cliente.getCedula();
        return super.ejecutar(consulta);
    }
    
    public boolean eliminarClinete(int cedula) {
        String consulta = "delete from cliente where cedula=" + cedula;
        return super.ejecutar(consulta);
    }
    
     public ArrayList<Cliente> listar() {
        ArrayList<Cliente> lista = new ArrayList<>();
        String consulta = "select cedula,nombre,apellido,correo,telefono,direccion from cliente ";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                Cliente cli = new Cliente();
                cli.setCedula(resultadoDB.getInt("cedula"));
                cli.setNombre(resultadoDB.getString("nombre"));
                cli.setApellido(resultadoDB.getString("apellido"));
                cli.setCorreo(resultadoDB.getString("correo"));
                cli.setCelular(resultadoDB.getInt("telefono"));
                cli.setDireccion(resultadoDB.getString("direccion"));
                lista.add(cli);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }
}
