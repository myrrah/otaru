/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Drago1
 */
public class Stock {

    int bodega;
    int producto;
    int cantidad;

    public Stock(int bodega, int producto, int cantidad) {
        this.bodega = bodega;
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Stock() {
    }
    
    

    public int getBodega() {
        return bodega;
    }

    public void setBodega(int bodega) {
        this.bodega = bodega;
    }

    public int getProducto() {
        return producto;
    }

    public void setProducto(int producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
}
