/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.ClienteDAO;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelo.Bodega;
import modelo.Cliente;

/**
 *
 * @author USUARIO WINDOWS
 */
public class CtlCliente {
    
    ClienteDAO dao = new ClienteDAO();
    LogicaCliente lb = new LogicaCliente();
    
    public boolean guardar(int cedula, String nombre, String apellido, String correo, int celular, String direccion){
        return lb.crearCliente(cedula, nombre, apellido, correo, celular, direccion);
    }
    public boolean modificar(int cedula, String nombre, String apellido, String correo, int celular, String direccion){
        return lb.modificar(cedula, nombre, apellido, correo, celular, direccion);
    }
    public boolean eliminar(int codigo){
        return lb.eliminar(codigo);
    }
    public Cliente buscar(int codigo){
        return lb.buscar(codigo);
    }
    
    public ArrayList<Cliente> listar() {
        return lb.listar();
    }
    
}
