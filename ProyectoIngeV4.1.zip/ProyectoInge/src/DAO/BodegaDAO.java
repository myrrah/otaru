/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Bodega;
import modelo.Producto;

/**
 *
 * @author Drago1
 */
public class BodegaDAO extends Conexion {

    public boolean guardarBodega(Bodega bodDAO) {
        String consulta = "insert into bodega(nombre,direccion,codigo,telefono) "
                + "values"
                + "('" + bodDAO.getNombre() + "','" + bodDAO.getDireccion() + "','"
                + bodDAO.getCodigo() + "','" + bodDAO.getTelefono() + "');";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

    public Bodega buscarBodega(int codigo) {
        String consulta = "select nombre,direccion,codigo,telefono from bodega "
                + "where codigo='" + codigo + "'";
        Bodega bodega = new Bodega();
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                bodega.setNombre(resultadoDB.getString("nombre"));
                bodega.setDireccion(resultadoDB.getString("direccion"));
                bodega.setCodigo(resultadoDB.getInt("codigo"));
                bodega.setTelefono(resultadoDB.getInt("telefono"));
            }
        } catch (SQLException ex) {
            System.out.println("Esto se Tosto");
        }
        return bodega;
    }

    public boolean modificarBodega(Bodega bodDAO) {
        String consulta = "update bodega set nombre='" + bodDAO.getNombre()
                + "',direccion='" + bodDAO.getDireccion()
                + "',telefono='" + bodDAO.getTelefono()
                + "' where codigo=" + bodDAO.getCodigo();
        return super.ejecutar(consulta);
    }

    public boolean eliminarBodega(int codigo) {
        String consulta = "delete from bodega where codigo=" + codigo;
        return super.ejecutar(consulta);
    }
    
    public ArrayList<Bodega> listarBodega() {
        ArrayList<Bodega> lista = new ArrayList<>();
        String consulta = "select nombre,"
                + "direccion,codigo,telefono from bodega";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                Bodega bodega = new Bodega();
                bodega.setNombre(resultadoDB.getString("nombre"));
                bodega.setDireccion(resultadoDB.getString("direccion"));
                bodega.setCodigo(resultadoDB.getInt("codigo"));
                bodega.setTelefono(resultadoDB.getInt("telefono"));
                lista.add(bodega);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }

}
