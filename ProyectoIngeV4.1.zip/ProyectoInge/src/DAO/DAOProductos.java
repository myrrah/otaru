/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexion.Conexion;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.CategoriaProducto;
import modelo.Producto;
import modelo.Proveedores;

/**
 *
 * @author Drago1
 */
public class DAOProductos extends Conexion{
     public boolean guardarProducto(Producto pro) {
        String consulta = "INSERT INTO productos (codigo,nombre,"
                + "umedida,idcategoria,idproveedor,precio) "
                + "VALUES ('" + pro.getCodigo() + " ', '" + pro.getNombre() + " ', '" + pro.getUmedida()
                + " ', '" + pro.getIdCategoria()+ " ', '" + pro.getIdProveedor()
                + "','" + pro.getPrecio()+ "'); ";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

    public Producto buscarProducto(int codigo) {
        String consulta = "select codigo,nombre,"
                + "umedida,idcategoria,idproveedor,precio from productos where codigo ='" + codigo + "'";
        Producto pro = new Producto();
        System.out.println(consulta);
        super.ejecutarRetorno(consulta);
        try {
            if (resultadoDB.next()) {
                pro.setCodigo(resultadoDB.getInt("codigo"));
                pro.setNombre(resultadoDB.getString("nombre"));
                pro.setUmedida(resultadoDB.getString("umedida"));
                pro.setIdCategoria(resultadoDB.getInt("idcategoria"));
                pro.setIdProveedor(resultadoDB.getInt("idproveedor"));
                pro.setPrecio(resultadoDB.getInt("precio"));
            }
        } catch (SQLException ex) {
            System.out.println("Fallo al consultar");
            return null;
        }
        return pro;

    }

   

    public ArrayList<Producto> listarProducto() {
        ArrayList<Producto> lista = new ArrayList<>();
        String consulta = "select codigo,nombre,"
                + "umedida,idcategoria,idproveedor,precio from productos";
        super.ejecutarRetorno(consulta);
        try {
            while (resultadoDB.next()) {
                Producto pro = new Producto();
                pro.setCodigo(resultadoDB.getInt("codigo"));
                pro.setNombre(resultadoDB.getString("nombre"));
                pro.setUmedida(resultadoDB.getString("umedida"));
                pro.setIdCategoria(resultadoDB.getInt("idcategoria"));
                pro.setIdProveedor(resultadoDB.getInt("idproveedor"));
                pro.setPrecio(resultadoDB.getInt("precio"));
                lista.add(pro);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return lista;
    }

    public boolean eliminarProducto(int codigo) {
        String consulta = "delete from productos where codigo =" + codigo;
        return super.ejecutar(consulta);
    }

    public boolean modificarProducto(Producto pro) {
        String consulta = "UPDATE productos SET codigo='" + pro.getCodigo() + "', "
                + " nombre='" + pro.getNombre() + "', umedida='" + pro.getUmedida()+ "', "
                +" idcategoria='" + pro.getIdCategoria()+ "', idproveedor='"+ pro.getIdProveedor()
                +"', precio='"+ pro.getPrecio()+"'"
                + " WHERE codigo='" + pro.getCodigo() + "'";
        System.out.println(consulta);
        return super.ejecutar(consulta);
    }

}
