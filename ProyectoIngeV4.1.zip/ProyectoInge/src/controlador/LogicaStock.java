/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import BO.BOStock;
import DAO.BodegaDAO;
import DAO.DAOProductos;
import DAO.DAOStock;
import Vista.Productos;
import java.util.ArrayList;
import modelo.Bodega;
import modelo.Producto;
import modelo.Stock;

/**
 *
 * @author Drago1
 */
public class LogicaStock {

    DAOStock ds = new DAOStock();
    DAOProductos dp = new DAOProductos();
    BodegaDAO db = new BodegaDAO();

    public boolean guardar(Bodega bodega, Producto producto, int cantidad) {
        Stock stock = new Stock(bodega.getCodigo(), producto.getCodigo(), cantidad);
        if (ds.buscarStock(bodega.getCodigo()).getBodega() == bodega.getCodigo()) {
            return false;
        }
        if (ds.guardarStock(stock)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean modificar(Bodega bodega, Producto producto, int cantidad) {
        Stock stock = new Stock(bodega.getCodigo(), producto.getCodigo(), cantidad);
        if (ds.buscarStock(bodega.getCodigo()).getBodega() == bodega.getCodigo()) {
            if (ds.buscarStock(bodega.getCodigo()).getProducto() == producto.getCodigo()) {
                if (ds.modificarStock(stock)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public ArrayList<BOStock> listar(Bodega bodega){
        ArrayList<Stock> lista = new ArrayList<>();
        lista=ds.listar(bodega.getCodigo());
        ArrayList<BOStock> listaS= new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            Bodega bodega1 = new Bodega();
            Producto pro = new Producto();
            bodega1=db.buscarBodega(lista.get(i).getBodega());
            pro=dp.buscarProducto(lista.get(i).getProducto());
            BOStock bo= new BOStock (bodega1, pro,lista.get(i).getCantidad());
            listaS.add(bo);
        }
        return listaS;
    }

}
